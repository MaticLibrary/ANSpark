package pl.ANSpark.matchupbackend.service;

import org.springframework.stereotype.Service;
import pl.ANSpark.matchupbackend.dto.response.MatchResponse;
import pl.ANSpark.matchupbackend.dto.response.ProfileResponse;
import pl.ANSpark.matchupbackend.model.Match;
import pl.ANSpark.matchupbackend.model.Profile;
import pl.ANSpark.matchupbackend.repository.MatchRepository;
import pl.ANSpark.matchupbackend.repository.ProfileRepository;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class MatchService {
    private final MatchRepository matchRepository;
    private final ProfileRepository profileRepository;

    public MatchService(MatchRepository matchRepository, ProfileRepository profileRepository) {
        this.matchRepository = matchRepository;
        this.profileRepository = profileRepository;
    }
    public List<MatchResponse> getMatches(UUID userId) {
        Profile currentProfile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("not found: " + userId));

        List<Match> matches = matchRepository.findAllByProfileId(currentProfile.getId());
        return matches.stream()
                .map(match -> mapToMatchResponse(match, currentProfile))
                .collect(Collectors.toList());
    }

    private MatchResponse mapToMatchResponse(Match match, Profile currentProfile) {
        Profile otherProfile = match.getProfile1().getId().equals(currentProfile.getId())
                ? match.getProfile2()
                : match.getProfile1();

        ProfileResponse profileResponse = mapToProfileResponse(otherProfile);

        MatchResponse response = new MatchResponse();
        response.setMatchId(match.getId());
        response.setProfile(profileResponse);
        response.setLastMessage(null);
        response.setCreatedAt(match.getCreatedAt());
        return response;
    }

    private ProfileResponse mapToProfileResponse(Profile profile) {
        ProfileResponse response = new ProfileResponse();
        response.setId(profile.getId());
        response.setDisplayName(profile.getDisplayName());
        response.setBirthDate(profile.getBirthDate());
        response.setGender(profile.getGender());
        response.setPreference(profile.getPreference());
        response.setBio(profile.getBio());
        response.setCity(profile.getCity());
        response.setAvatarUrl(profile.getAvatarUrl());
        response.setPhotos(profile.getPhotos());
        return response;



    }
}
