package pl.ANSpark.matchupbackend.controller;


import jakarta.validation.Valid;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import pl.ANSpark.matchupbackend.dto.request.LikeRequest;
import pl.ANSpark.matchupbackend.dto.response.MatchResponse;
import pl.ANSpark.matchupbackend.security.UserDetailsImpl;
import pl.ANSpark.matchupbackend.service.LikeService;
import pl.ANSpark.matchupbackend.service.MatchService;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/likes")
public class LikeController {
    private final LikeService likeService;
    private final MatchService matchService;

    public LikeController(LikeService likeService, MatchService matchService) {
        this.likeService = likeService;
        this.matchService = matchService;
    }



    @PostMapping("/")
    public Map<String, Object> like(@Valid @RequestBody LikeRequest likeRequest) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();

        return likeService.likeProfile(userId,likeRequest);

    }

    @GetMapping("/matches")
    public List<MatchResponse> getMatches() {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();

        return matchService.getMatches(userId);

    }



}
