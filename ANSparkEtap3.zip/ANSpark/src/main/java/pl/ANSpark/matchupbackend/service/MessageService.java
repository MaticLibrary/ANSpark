package pl.ANSpark.matchupbackend.service;


import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import pl.ANSpark.matchupbackend.model.Match;
import pl.ANSpark.matchupbackend.model.Message;
import pl.ANSpark.matchupbackend.model.Profile;
import pl.ANSpark.matchupbackend.repository.MatchRepository;
import pl.ANSpark.matchupbackend.repository.MessageRepository;
import pl.ANSpark.matchupbackend.repository.ProfileRepository;

import java.util.List;
import java.util.UUID;

@Service
public class MessageService {
    private final MessageRepository messageRepository;
    private final MatchRepository matchRepository;
    private final ProfileRepository profileRepository;

    public MessageService(MessageRepository messageRepository, MatchRepository matchRepository, ProfileRepository profileRepository) {
        this.messageRepository = messageRepository;
        this.matchRepository = matchRepository;
        this.profileRepository = profileRepository;

    }


    @Transactional(readOnly = true)
    public List<Message> getMessages(Long matchId, UUID userId) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new RuntimeException("Матч з ID " + matchId + " не знайдено"));
        Profile currentProfile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Профіль не знайдено для userId: " + userId));
        if (!match.getProfile1().getId().equals(currentProfile.getId()) &&
                !match.getProfile2().getId().equals(currentProfile.getId())) {
            throw new RuntimeException("Користувач не є учасником цього чату");
        }
        return messageRepository.findByMatchIdOrderBySentAtAsc(matchId);
    }

    @Transactional
    public Message sendMessage(Long matchId, UUID userId, String content) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new RuntimeException("Матч з ID " + matchId + " не знайдено"));

        Profile senderProfile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Профіль не знайдено для userId: " + userId));

        if (!match.getProfile1().getId().equals(senderProfile.getId()) &&
                !match.getProfile2().getId().equals(senderProfile.getId())) {
            throw new RuntimeException("Користувач не є учасником цього чату");
        }

        Message message = new Message();
        message.setMatch(match);
        message.setSenderProfile(senderProfile);
        message.setContent(content);
        return messageRepository.save(message);
    }
}
