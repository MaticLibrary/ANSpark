package pl.ANSpark.matchupbackend.controller;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import pl.ANSpark.matchupbackend.model.Message;
import pl.ANSpark.matchupbackend.security.UserDetailsImpl;
import pl.ANSpark.matchupbackend.service.MatchService;
import pl.ANSpark.matchupbackend.service.MessageService;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/matches")
public class MatchController {

    private final MessageService messageService;

    public MatchController(MessageService messageService) {
        this.messageService = messageService;
    }






    @GetMapping("/{matchId}/messages")
    public List<Message> getMessages(@PathVariable Long matchId) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();

        return messageService.getMessages(matchId, userId);
    }

    @PostMapping("/{matchId}/messages")
    public Message addMessage(@PathVariable Long matchId, @RequestBody String message) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();

        return messageService.sendMessage(matchId,userId,message);
    }


}
