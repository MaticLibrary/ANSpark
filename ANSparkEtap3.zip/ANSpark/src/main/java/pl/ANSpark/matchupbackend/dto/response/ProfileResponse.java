package pl.ANSpark.matchupbackend.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pl.ANSpark.matchupbackend.model.GenderEnum;
import pl.ANSpark.matchupbackend.model.Photo;
import pl.ANSpark.matchupbackend.model.PreferenceEnum;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor      // <-- dodaj to!
@AllArgsConstructor     // zostaw
public class ProfileResponse {
    private Long id;
    private String displayName;
    private LocalDate birthDate;
    private GenderEnum gender;
    private PreferenceEnum preference;
    private String bio;
    private String city;
    private String avatarUrl;

    @JsonIgnore
    private List<Photo> photos;

    private int age;
}