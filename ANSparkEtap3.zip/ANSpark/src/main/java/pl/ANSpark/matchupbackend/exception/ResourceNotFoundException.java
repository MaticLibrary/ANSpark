package pl.ANSpark.matchupbackend.exception;

public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }

    public ResourceNotFoundException(String resourceName, String fieldName, Object fieldValue) {
        super(String.format("%s Not found %s: '%s'", resourceName, fieldName, fieldValue));
    }
}