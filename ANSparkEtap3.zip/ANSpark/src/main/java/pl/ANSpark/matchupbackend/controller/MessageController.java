package pl.ANSpark.matchupbackend.controller;

import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import pl.ANSpark.matchupbackend.model.Message;
import pl.ANSpark.matchupbackend.service.MessageService;

import java.security.Principal;
import java.util.UUID;

@Controller
public class MessageController {

    private final MessageService messageService;
    private final SimpMessagingTemplate messagingTemplate;

    public MessageController(MessageService messageService, SimpMessagingTemplate messagingTemplate) {
        this.messageService = messageService;
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/chat/{matchId}")
    public void sendMessage(@DestinationVariable Long matchId,
                            @Payload String content,
                            Principal principal) {
        UUID userId = UUID.fromString(principal.getName()); // Тимчасово, не працюватиме
        Message savedMessage = messageService.sendMessage(matchId, userId, content);
        messagingTemplate.convertAndSendToUser(
                getOtherParticipantId(matchId, userId).toString(),
                "/queue/messages",
                savedMessage
        );
    }

    private UUID getOtherParticipantId(Long matchId, UUID currentUserId) {
        return null;
    }
}