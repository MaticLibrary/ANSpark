// Jwt token for api request(take request from front)

package pl.ANSpark.matchupbackend.config;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;
import pl.ANSpark.matchupbackend.security.JwtUtils;
import pl.ANSpark.matchupbackend.security.UserDetailsImpl;
import pl.ANSpark.matchupbackend.service.UserService;

import java.io.IOException;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtils jwtUtils;
    private final UserService userService;


    public JwtAuthenticationFilter(JwtUtils jwtUtils, UserService userService) {
        this.jwtUtils = jwtUtils;
        this.userService = userService;
    }

    @Override
    public void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws IOException, ServletException {
        try{

            String token = req.getHeader("Authorization");

            if (token != null && token.startsWith("Bearer ")) {
                String tokenValue = token.substring(7);

                if(jwtUtils.validateToken(tokenValue)){
                    String email = jwtUtils.getEmailFromToken(tokenValue);

                    UserDetails userDetails = userService.loadUserByUsername(email);

                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(
                                    userDetails, null, userDetails.getAuthorities());

                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));

                    SecurityContextHolder.getContext().setAuthentication(authentication);


                }





            }



        } catch (Exception e){
            System.out.println("JWT authentication failed: " + e.getMessage());

        }
        chain.doFilter(req, res);
    }


}
