package pl.ANSpark.matchupbackend.service;

import org.springframework.stereotype.Service;
import pl.ANSpark.matchupbackend.dto.request.ProfileUpdateRequest;
import pl.ANSpark.matchupbackend.dto.response.ProfileResponse;
import pl.ANSpark.matchupbackend.model.Profile;
import pl.ANSpark.matchupbackend.repository.ProfileRepository;
import pl.ANSpark.matchupbackend.repository.UserRepository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.util.UUID;

@Service
public class ProfileService {
    private final ProfileRepository profileRepository;
    private final UserRepository userRepository;

    public ProfileService(ProfileRepository profileRepository, UserRepository userRepository) {
        this.profileRepository = profileRepository;
        this.userRepository = userRepository;
    }


    public ProfileResponse getMyProfile(UUID userId) {
        Profile profile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Profile not found"));

        ProfileResponse profileResponse = new ProfileResponse();
        profileResponse.setId(profile.getId());
        profileResponse.setDisplayName(profile.getDisplayName());
        profileResponse.setBirthDate(profile.getBirthDate());
        profileResponse.setGender(profile.getGender());
        profileResponse.setPreference(profile.getPreference());
        profileResponse.setBio(profile.getBio());
        profileResponse.setCity(profile.getCity());
        profileResponse.setAvatarUrl(profile.getAvatarUrl());
        profileResponse.setPhotos(profile.getPhotos());
        profileResponse.setAge(Period.between(profile.getBirthDate(), LocalDate.now()).getYears());

        return profileResponse;

    }

    public ProfileResponse updateProfile(UUID userId, ProfileUpdateRequest req) {
        Profile profile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Profile not found"));

        if (req.getDisplayName() != null) profile.setDisplayName(req.getDisplayName());
        if (req.getBio() != null) profile.setBio(req.getBio());
        if (req.getCity() != null) profile.setCity(req.getCity());
        if (req.getPreference() != null) profile.setPreference(req.getPreference());


        if (req.getLatitude() != null) {
            profile.setLatitude(BigDecimal.valueOf(req.getLatitude()));
        }
        if (req.getLongitude() != null) {
            profile.setLongitude(BigDecimal.valueOf(req.getLongitude()));
        }

        Profile updated = profileRepository.save(profile);

        ProfileResponse profileResponse = new ProfileResponse();
        profileResponse.setId(updated.getId());
        profileResponse.setDisplayName(updated.getDisplayName());
        profileResponse.setBirthDate(updated.getBirthDate());
        profileResponse.setGender(updated.getGender());
        profileResponse.setPreference(updated.getPreference());
        profileResponse.setBio(updated.getBio());
        profileResponse.setCity(updated.getCity());
        profileResponse.setAvatarUrl(updated.getAvatarUrl());
        profileResponse.setPhotos(updated.getPhotos());
        profileResponse.setAge(Period.between(updated.getBirthDate(), LocalDate.now()).getYears());

        return profileResponse;
    }


}
