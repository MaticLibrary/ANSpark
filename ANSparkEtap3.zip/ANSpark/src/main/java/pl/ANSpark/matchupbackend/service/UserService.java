package pl.ANSpark.matchupbackend.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import pl.ANSpark.matchupbackend.model.User;
import pl.ANSpark.matchupbackend.repository.UserRepository;
import pl.ANSpark.matchupbackend.security.UserDetailsImpl;

@Service
public class UserService implements UserDetailsService {  // ← DODAJ TO!

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
        return UserDetailsImpl.build(user);
    }
}