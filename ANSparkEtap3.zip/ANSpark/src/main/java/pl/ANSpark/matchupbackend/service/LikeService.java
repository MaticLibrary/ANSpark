package pl.ANSpark.matchupbackend.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pl.ANSpark.matchupbackend.dto.request.LikeRequest;
import pl.ANSpark.matchupbackend.model.Like;
import pl.ANSpark.matchupbackend.model.Match;
import pl.ANSpark.matchupbackend.model.Profile;
import pl.ANSpark.matchupbackend.repository.BlockRepository;
import pl.ANSpark.matchupbackend.repository.LikeRepository;
import pl.ANSpark.matchupbackend.repository.MatchRepository;
import pl.ANSpark.matchupbackend.repository.ProfileRepository;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class LikeService {

    private final LikeRepository likeRepository;
    private final MatchRepository matchRepository;
    private final ProfileRepository profileRepository;
    private final BlockRepository blockRepository;

    public Map<String, Object> likeProfile(UUID userId, LikeRequest request) {
        Profile fromProfile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Nie znaleziono profilu dla użytkownika: " + userId));

        Profile toProfile = profileRepository.findById(request.getToProfileId())
                .orElseThrow(() -> new RuntimeException("Nie znaleziono profilu o ID: " + request.getToProfileId()));

        if (fromProfile.getId().equals(toProfile.getId())) {
            throw new RuntimeException("Nie możesz polubić samego siebie");
        }

        boolean blocked = blockRepository.existsByBlockerProfileIdAndBlockedProfileId(fromProfile.getId(), toProfile.getId())
                || blockRepository.existsByBlockerProfileIdAndBlockedProfileId(toProfile.getId(), fromProfile.getId());
        if (blocked) {
            throw new RuntimeException("Nie możesz polubić tego profilu (blokada)");
        }

        boolean alreadyLiked = likeRepository.existsByFromProfileIdAndToProfileId(fromProfile.getId(), toProfile.getId());
        if (alreadyLiked) {
            throw new RuntimeException("Już polubiłeś ten profil");
        }

        Like like = new Like();
        like.setFromProfile(fromProfile);
        like.setToProfile(toProfile);
        likeRepository.save(like);
        boolean mutual = likeRepository.existsByFromProfileIdAndToProfileId(toProfile.getId(), fromProfile.getId());

        Map<String, Object> response = new HashMap<>();
        response.put("isMatch", false);
        response.put("matchId", null);

        if (mutual) {
            Match match = new Match();
            if (fromProfile.getId() < toProfile.getId()) {
                match.setProfile1(fromProfile);
                match.setProfile2(toProfile);
            } else {
                match.setProfile1(toProfile);
                match.setProfile2(fromProfile);
            }
            matchRepository.save(match);

            response.put("isMatch", true);
            response.put("matchId", match.getId());
        }

        return response;
    }
}