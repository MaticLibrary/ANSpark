package pl.ANSpark.matchupbackend.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import pl.ANSpark.matchupbackend.model.Photo;
import pl.ANSpark.matchupbackend.model.Profile;
import pl.ANSpark.matchupbackend.repository.PhotoRepository;
import pl.ANSpark.matchupbackend.repository.ProfileRepository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;

@Service
public class PhotoService {

    private final PhotoRepository photoRepository;
    private final ProfileRepository profileRepository;
    private static final List<String> ALLOWED_CONTENT_TYPES =
            List.of("image/jpeg", "image/jpg", "image/png", "image/webp");

    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
    private static final int MAX_PHOTOS = 6;

    private static final String UPLOAD_DIR = "uploads";

    public PhotoService(PhotoRepository photoRepository, ProfileRepository profileRepository) {
        this.photoRepository = photoRepository;
        this.profileRepository = profileRepository;
    }

    public Photo uploadPhoto(UUID userId, MultipartFile file) {
        Profile profile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Profil nie znaleziony"));


        if (profile.getPhotos().size() >= MAX_PHOTOS) {
            throw new RuntimeException("Maksymalna liczba zdjęć to " + MAX_PHOTOS);
        }


        String contentType = file.getContentType();
        if (contentType == null || !ALLOWED_CONTENT_TYPES.contains(contentType)) {
            throw new RuntimeException("Niedozwolony format pliku. Dozwolone: JPEG, PNG, WEBP");
        }


        if (file.getSize() > MAX_FILE_SIZE) {
            throw new RuntimeException("Plik jest za duży. Maksymalny rozmiar to 10 MB");
        }

        try {
            Path userDir = Paths.get(UPLOAD_DIR, userId.toString());
            Files.createDirectories(userDir);

            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }

            String filename = UUID.randomUUID().toString() + extension;
            Path filePath = userDir.resolve(filename);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            String fileUrl = "/uploads/" + userId + "/" + filename;
            Photo photo = new Photo();
            photo.setProfile(profile);
            photo.setUrl(fileUrl);
            photo.setOrderIndex(profile.getPhotos().size());

            Photo savedPhoto = photoRepository.save(photo);
            if (profile.getPhotos().isEmpty()) {
                profile.setAvatarUrl(fileUrl);
                profileRepository.save(profile);
            }

            return savedPhoto;

        } catch (IOException e) {
            throw new RuntimeException("Nie udało się zapisać pliku: " + e.getMessage(), e);
        }
    }

    public void deletePhoto(UUID userId, Long photoId) {
        Photo photo = photoRepository.findById(photoId)
                .orElseThrow(() -> new RuntimeException("Zdjęcie nie znalezione"));
        if (!photo.getProfile().getUser().getId().equals(userId)) {
            throw new RuntimeException("Nie masz uprawnień do usunięcia tego zdjęcia");
        }

        try {
            String filePath = photo.getUrl().replace("/uploads", UPLOAD_DIR);
            Path path = Paths.get(filePath);
            Files.deleteIfExists(path);
            photoRepository.delete(photo);
            Profile profile = photo.getProfile();
            if (photo.getUrl().equals(profile.getAvatarUrl())) {
                if (!profile.getPhotos().isEmpty()) {
                    Photo firstPhoto = profile.getPhotos().stream()
                            .findFirst()
                            .orElse(null);
                    if (firstPhoto != null) {
                        profile.setAvatarUrl(firstPhoto.getUrl());
                    } else {
                        profile.setAvatarUrl(null);
                    }
                } else {
                    profile.setAvatarUrl(null);
                }
                profileRepository.save(profile);
            }

        } catch (IOException e) {
            throw new RuntimeException("Nie udało się usunąć pliku: " + e.getMessage(), e);
        }
    }
}