package pl.ANSpark.matchupbackend.service;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import pl.ANSpark.matchupbackend.dto.request.LoginRequest;
import pl.ANSpark.matchupbackend.dto.request.RegisterRequest;
import pl.ANSpark.matchupbackend.dto.response.AuthResponse;
import pl.ANSpark.matchupbackend.dto.response.ProfileResponse;
import pl.ANSpark.matchupbackend.model.Profile;
import pl.ANSpark.matchupbackend.model.User;
import pl.ANSpark.matchupbackend.repository.ProfileRepository;
import pl.ANSpark.matchupbackend.repository.UserRepository;
import pl.ANSpark.matchupbackend.security.JwtUtils;

import java.time.LocalDate;
import java.time.Period;
import java.util.UUID;


@Service
public class AuthService {
    private final UserRepository userRepository;
    private final ProfileRepository profileRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final AuthenticationManager authenticationManager;

    public AuthService(UserRepository userRepository, ProfileRepository profileRepository, PasswordEncoder passwordEncoder, JwtUtils jwtUtils, AuthenticationManager authenticationManager) {
        this.userRepository = userRepository;
        this.profileRepository = profileRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
        this.authenticationManager = authenticationManager;
    }

    @Transactional
    public AuthResponse register(RegisterRequest req) {

        if(userRepository.existsByEmail(req.getEmail())) {
            throw new UsernameNotFoundException("Email already exists");
        }

        if(req.getBirthDate().plusYears(18).isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Birth date is after 18 years");
        }

        User user = new User();
        user.setEmail(req.getEmail());
        user.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        user = userRepository.save(user);


        Profile profile = new Profile();
        profile.setUser(user);
        profile.setDisplayName(req.getDisplayName());
        profile.setBirthDate(req.getBirthDate());
        profile.setGender(req.getGender());
        profile.setPreference(req.getPreference());
        profile = profileRepository.save(profile);

        String token = jwtUtils.generateToken(user.getEmail(), user.getId());

        ProfileResponse profileResponse = mapToProfileResponse(profile);

        return new AuthResponse(token, user.getId(), user.getEmail(), profileResponse);

    }

//    public AuthResponse login(LoginRequest req) {
//
//        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
//        User user = userRepository.findByEmail(req.getEmail()).orElseThrow(() -> new RuntimeException("User not found"));
//
//        Profile profile = profileRepository.findByUserId(user.getId()).orElseThrow(() -> new RuntimeException("Profile not found"));
//
//        String token = jwtUtils.generateToken(user.getEmail(), user.getId());
//
//        ProfileResponse profileResponse = mapToProfileResponse(profile);
//
//        return new AuthResponse(token, user.getId(), user.getEmail(), profileResponse);
//
//
//
//
//    }

//    public AuthResponse login(LoginRequest req) {
//        User user = userRepository.findByEmail(req.getEmail())
//                .orElseThrow(() -> new RuntimeException("User not found"));
//
//        String token = "test-token-123";
//
//        return new AuthResponse(token, user.getId(), user.getEmail(), null);
//    }
public AuthResponse login(LoginRequest req) {
    authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword())
    );

    User user = userRepository.findByEmail(req.getEmail())
            .orElseThrow(() -> new RuntimeException("User not found"));

    Profile profile = profileRepository.findByUserId(user.getId())
            .orElseThrow(() -> new RuntimeException("Profile not found"));

    String token = jwtUtils.generateToken(user.getEmail(), user.getId());

    ProfileResponse profileResponse = mapToProfileResponse(profile);

    return new AuthResponse(token, user.getId(), user.getEmail(), profileResponse);
}

    private ProfileResponse mapToProfileResponse(Profile profile) {
        ProfileResponse response = new ProfileResponse();
        response.setId(profile.getId());
        response.setDisplayName(profile.getDisplayName());
        response.setBirthDate(profile.getBirthDate());
        response.setGender(profile.getGender());
        response.setPreference(profile.getPreference());
        response.setBio(profile.getBio());
        response.setCity(profile.getCity());
        response.setAvatarUrl(profile.getAvatarUrl());
        // photos поки що пропускаємо або встановлюємо null
        // response.setPhotos(profile.getPhotos()); //
        response.setAge(calculateAge(profile.getBirthDate()));
        return response;
    }

    private int calculateAge(LocalDate birthDate) {
        return Period.between(birthDate, LocalDate.now()).getYears();
    }





}
