package pl.ANSpark.matchupbackend.controller;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import pl.ANSpark.matchupbackend.dto.request.ProfileUpdateRequest;
import pl.ANSpark.matchupbackend.dto.response.ProfileResponse;
import pl.ANSpark.matchupbackend.model.Photo;
import pl.ANSpark.matchupbackend.security.UserDetailsImpl;
import pl.ANSpark.matchupbackend.service.PhotoService;
import pl.ANSpark.matchupbackend.service.ProfileService;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/profile")
public class ProfileController {

    private final ProfileService profileService;
    private final PhotoService photoService;

    public ProfileController(ProfileService profileService, PhotoService photoService) {
        this.profileService = profileService;
        this.photoService = photoService;
    }

    @GetMapping("/me")
    public ProfileResponse me_get() {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();

        return profileService.getMyProfile(userId);
    }

    @PutMapping("/me")
    public ProfileResponse me_update(@Valid @RequestBody ProfileUpdateRequest profileUpdateRequest) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();

        return profileService.updateProfile(userId, profileUpdateRequest);

    }

    @PostMapping("/me/photo")
    public Photo me_post(@RequestParam("file") MultipartFile file) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();


        return photoService.uploadPhoto(userId, file);
    }

    @DeleteMapping("me/photo/{photoId}")
        public ResponseEntity<Void> me_delete(@PathVariable Long photoId) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID userId = userDetails.getId();

        photoService.deletePhoto(userId, photoId);

        return ResponseEntity.noContent().build();



        }
    }

